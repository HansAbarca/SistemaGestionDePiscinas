import 'package:flutter/material.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {}

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  String _AjustesInventario = '';
  String get AjustesInventario => _AjustesInventario;
  set AjustesInventario(String value) {
    _AjustesInventario = value;
  }

  bool _botonOpcionesVisivilidad = false;
  bool get botonOpcionesVisivilidad => _botonOpcionesVisivilidad;
  set botonOpcionesVisivilidad(bool value) {
    _botonOpcionesVisivilidad = value;
  }

  bool _ItemAnadido = false;
  bool get ItemAnadido => _ItemAnadido;
  set ItemAnadido(bool value) {
    _ItemAnadido = value;
  }

  bool _CambiarOrden = false;
  bool get CambiarOrden => _CambiarOrden;
  set CambiarOrden(bool value) {
    _CambiarOrden = value;
  }

  bool _anadirEmpleadoConfirmacion = false;
  bool get anadirEmpleadoConfirmacion => _anadirEmpleadoConfirmacion;
  set anadirEmpleadoConfirmacion(bool value) {
    _anadirEmpleadoConfirmacion = value;
  }

  bool _VerificaAnadirEmpleado = false;
  bool get VerificaAnadirEmpleado => _VerificaAnadirEmpleado;
  set VerificaAnadirEmpleado(bool value) {
    _VerificaAnadirEmpleado = value;
  }

  String _nombreSet = '';
  String get nombreSet => _nombreSet;
  set nombreSet(String value) {
    _nombreSet = value;
  }

  String _IDEmpleado = '';
  String get IDEmpleado => _IDEmpleado;
  set IDEmpleado(String value) {
    _IDEmpleado = value;
  }

  bool _Cargando = false;
  bool get Cargando => _Cargando;
  set Cargando(bool value) {
    _Cargando = value;
  }

  String _Rol = '';
  String get Rol => _Rol;
  set Rol(String value) {
    _Rol = value;
  }
}
