import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';

class CarritoRecord extends FirestoreRecord {
  CarritoRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "placeholder" field.
  String? _placeholder;
  String get placeholder => _placeholder ?? '';
  bool hasPlaceholder() => _placeholder != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _placeholder = snapshotData['placeholder'] as String?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('Carrito')
          : FirebaseFirestore.instance.collectionGroup('Carrito');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('Carrito').doc(id);

  static Stream<CarritoRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => CarritoRecord.fromSnapshot(s));

  static Future<CarritoRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => CarritoRecord.fromSnapshot(s));

  static CarritoRecord fromSnapshot(DocumentSnapshot snapshot) =>
      CarritoRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static CarritoRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      CarritoRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'CarritoRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is CarritoRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createCarritoRecordData({
  String? placeholder,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'placeholder': placeholder,
    }.withoutNulls,
  );

  return firestoreData;
}

class CarritoRecordDocumentEquality implements Equality<CarritoRecord> {
  const CarritoRecordDocumentEquality();

  @override
  bool equals(CarritoRecord? e1, CarritoRecord? e2) {
    return e1?.placeholder == e2?.placeholder;
  }

  @override
  int hash(CarritoRecord? e) => const ListEquality().hash([e?.placeholder]);

  @override
  bool isValidKey(Object? o) => o is CarritoRecord;
}
