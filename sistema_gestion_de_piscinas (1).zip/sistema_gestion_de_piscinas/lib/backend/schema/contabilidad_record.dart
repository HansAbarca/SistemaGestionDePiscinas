import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ContabilidadRecord extends FirestoreRecord {
  ContabilidadRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "Gasto" field.
  double? _gasto;
  double get gasto => _gasto ?? 0.0;
  bool hasGasto() => _gasto != null;

  // "Fecha" field.
  DateTime? _fecha;
  DateTime? get fecha => _fecha;
  bool hasFecha() => _fecha != null;

  // "Descripcion" field.
  String? _descripcion;
  String get descripcion => _descripcion ?? '';
  bool hasDescripcion() => _descripcion != null;

  void _initializeFields() {
    _gasto = castToType<double>(snapshotData['Gasto']);
    _fecha = snapshotData['Fecha'] as DateTime?;
    _descripcion = snapshotData['Descripcion'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Contabilidad');

  static Stream<ContabilidadRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ContabilidadRecord.fromSnapshot(s));

  static Future<ContabilidadRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ContabilidadRecord.fromSnapshot(s));

  static ContabilidadRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ContabilidadRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ContabilidadRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ContabilidadRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ContabilidadRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ContabilidadRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createContabilidadRecordData({
  double? gasto,
  DateTime? fecha,
  String? descripcion,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'Gasto': gasto,
      'Fecha': fecha,
      'Descripcion': descripcion,
    }.withoutNulls,
  );

  return firestoreData;
}

class ContabilidadRecordDocumentEquality
    implements Equality<ContabilidadRecord> {
  const ContabilidadRecordDocumentEquality();

  @override
  bool equals(ContabilidadRecord? e1, ContabilidadRecord? e2) {
    return e1?.gasto == e2?.gasto &&
        e1?.fecha == e2?.fecha &&
        e1?.descripcion == e2?.descripcion;
  }

  @override
  int hash(ContabilidadRecord? e) =>
      const ListEquality().hash([e?.gasto, e?.fecha, e?.descripcion]);

  @override
  bool isValidKey(Object? o) => o is ContabilidadRecord;
}
