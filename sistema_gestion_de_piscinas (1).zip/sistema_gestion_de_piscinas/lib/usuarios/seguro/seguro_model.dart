import '/flutter_flow/flutter_flow_util.dart';
import 'seguro_widget.dart' show SeguroWidget;
import 'package:flutter/material.dart';

class SeguroModel extends FlutterFlowModel<SeguroWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
