import '/flutter_flow/flutter_flow_util.dart';
import 'item_widget.dart' show ItemWidget;
import 'package:flutter/material.dart';

class ItemModel extends FlutterFlowModel<ItemWidget> {
  ///  Local state fields for this component.

  FFUploadedFile? imagenBytes;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
