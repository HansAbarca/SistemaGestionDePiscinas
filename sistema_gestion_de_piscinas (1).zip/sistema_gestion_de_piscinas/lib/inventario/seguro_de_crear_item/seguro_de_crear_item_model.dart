import '/flutter_flow/flutter_flow_util.dart';
import 'seguro_de_crear_item_widget.dart' show SeguroDeCrearItemWidget;
import 'package:flutter/material.dart';

class SeguroDeCrearItemModel extends FlutterFlowModel<SeguroDeCrearItemWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
