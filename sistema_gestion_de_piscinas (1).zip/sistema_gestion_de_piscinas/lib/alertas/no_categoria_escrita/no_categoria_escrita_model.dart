import '/flutter_flow/flutter_flow_util.dart';
import 'no_categoria_escrita_widget.dart' show NoCategoriaEscritaWidget;
import 'package:flutter/material.dart';

class NoCategoriaEscritaModel
    extends FlutterFlowModel<NoCategoriaEscritaWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
