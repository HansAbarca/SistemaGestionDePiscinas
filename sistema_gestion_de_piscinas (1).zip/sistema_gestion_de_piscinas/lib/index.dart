// Export pages
export '/entrada/entrance/entrance_widget.dart' show EntranceWidget;
export '/entrada/entrar_login/entrar_login_widget.dart' show EntrarLoginWidget;
export '/home/home/home_widget.dart' show HomeWidget;
export '/inventario/inventario/inventario_widget.dart' show InventarioWidget;
export '/contabilidad/contabilidad_widget.dart' show ContabilidadWidget;
export '/asistentevirtual/asistentevirtual_widget.dart'
    show AsistentevirtualWidget;
export '/usuarios/usuarios/usuarios_widget.dart' show UsuariosWidget;
export '/datos/datos_widget.dart' show DatosWidget;
export '/logs/logs_widget.dart' show LogsWidget;
export '/guarda_documento/guarda_documento_widget.dart'
    show GuardaDocumentoWidget;
