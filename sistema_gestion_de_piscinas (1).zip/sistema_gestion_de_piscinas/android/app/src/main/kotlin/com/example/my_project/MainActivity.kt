package com.tesis.sistemagestiondepiscinas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
