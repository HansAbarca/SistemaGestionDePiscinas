import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: const FirebaseOptions(
            apiKey: "AIzaSyBbgdtij7JV9vOB-LMVgvpX7qEyJ3a0iss",
            authDomain: "multiservicios-y-piscinas.firebaseapp.com",
            projectId: "multiservicios-y-piscinas",
            storageBucket: "multiservicios-y-piscinas.appspot.com",
            messagingSenderId: "871923257983",
            appId: "1:871923257983:web:8bd8ed515e0e3e0d19254a",
            measurementId: "G-CXTCSCHJE1"));
  } else {
    await Firebase.initializeApp();
  }
}
