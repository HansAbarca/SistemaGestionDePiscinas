import '/flutter_flow/flutter_flow_util.dart';
import 'anadir_pregunta_general_widget.dart' show AnadirPreguntaGeneralWidget;
import 'package:flutter/material.dart';

class AnadirPreguntaGeneralModel
    extends FlutterFlowModel<AnadirPreguntaGeneralWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
