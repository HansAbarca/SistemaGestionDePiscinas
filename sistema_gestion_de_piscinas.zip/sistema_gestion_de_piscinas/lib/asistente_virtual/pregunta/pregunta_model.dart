import '/flutter_flow/flutter_flow_util.dart';
import 'pregunta_widget.dart' show PreguntaWidget;
import 'package:flutter/material.dart';

class PreguntaModel extends FlutterFlowModel<PreguntaWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
