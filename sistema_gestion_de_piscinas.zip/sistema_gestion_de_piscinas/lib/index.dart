// Export pages
export '/entrada/entrance/entrance_widget.dart' show EntranceWidget;
export '/entrada/entrar_login/entrar_login_widget.dart' show EntrarLoginWidget;
export '/home/home/home_widget.dart' show HomeWidget;
export '/modulos/inventario/inventario_widget.dart' show InventarioWidget;
export '/modulos/contabilidad/contabilidad_widget.dart' show ContabilidadWidget;
export '/modulos/asistentevirtual/asistentevirtual_widget.dart'
    show AsistentevirtualWidget;
export '/modulos/usuarios/usuarios_widget.dart' show UsuariosWidget;
export '/modulos/datos/datos_widget.dart' show DatosWidget;
export '/modulos/logs/logs_widget.dart' show LogsWidget;
