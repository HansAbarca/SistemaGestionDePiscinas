import '/flutter_flow/flutter_flow_util.dart';
import 'cantidad_invalida_widget.dart' show CantidadInvalidaWidget;
import 'package:flutter/material.dart';

class CantidadInvalidaModel extends FlutterFlowModel<CantidadInvalidaWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
