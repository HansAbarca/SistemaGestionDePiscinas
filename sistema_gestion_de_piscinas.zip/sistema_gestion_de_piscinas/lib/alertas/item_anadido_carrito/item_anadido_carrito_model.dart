import '/flutter_flow/flutter_flow_util.dart';
import 'item_anadido_carrito_widget.dart' show ItemAnadidoCarritoWidget;
import 'package:flutter/material.dart';

class ItemAnadidoCarritoModel
    extends FlutterFlowModel<ItemAnadidoCarritoWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
