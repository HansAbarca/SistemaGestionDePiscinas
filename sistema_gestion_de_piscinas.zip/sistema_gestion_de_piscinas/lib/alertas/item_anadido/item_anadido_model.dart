import '/flutter_flow/flutter_flow_util.dart';
import 'item_anadido_widget.dart' show ItemAnadidoWidget;
import 'package:flutter/material.dart';

class ItemAnadidoModel extends FlutterFlowModel<ItemAnadidoWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
