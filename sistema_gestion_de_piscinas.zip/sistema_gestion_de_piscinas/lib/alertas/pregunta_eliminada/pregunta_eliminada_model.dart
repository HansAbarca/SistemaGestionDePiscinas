import '/flutter_flow/flutter_flow_util.dart';
import 'pregunta_eliminada_widget.dart' show PreguntaEliminadaWidget;
import 'package:flutter/material.dart';

class PreguntaEliminadaModel extends FlutterFlowModel<PreguntaEliminadaWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
