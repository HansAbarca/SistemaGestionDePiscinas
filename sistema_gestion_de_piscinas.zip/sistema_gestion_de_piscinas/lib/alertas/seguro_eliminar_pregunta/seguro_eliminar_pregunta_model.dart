import '/flutter_flow/flutter_flow_util.dart';
import 'seguro_eliminar_pregunta_widget.dart' show SeguroEliminarPreguntaWidget;
import 'package:flutter/material.dart';

class SeguroEliminarPreguntaModel
    extends FlutterFlowModel<SeguroEliminarPreguntaWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
