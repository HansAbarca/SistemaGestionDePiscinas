import '/flutter_flow/flutter_flow_util.dart';
import 'seguro_de_eliminar_de_carrito_widget.dart'
    show SeguroDeEliminarDeCarritoWidget;
import 'package:flutter/material.dart';

class SeguroDeEliminarDeCarritoModel
    extends FlutterFlowModel<SeguroDeEliminarDeCarritoWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
