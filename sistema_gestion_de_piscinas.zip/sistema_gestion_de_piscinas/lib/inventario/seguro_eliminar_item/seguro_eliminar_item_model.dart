import '/flutter_flow/flutter_flow_util.dart';
import 'seguro_eliminar_item_widget.dart' show SeguroEliminarItemWidget;
import 'package:flutter/material.dart';

class SeguroEliminarItemModel
    extends FlutterFlowModel<SeguroEliminarItemWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
