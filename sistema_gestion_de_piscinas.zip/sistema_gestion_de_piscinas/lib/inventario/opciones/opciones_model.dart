import '/flutter_flow/flutter_flow_util.dart';
import 'opciones_widget.dart' show OpcionesWidget;
import 'package:flutter/material.dart';

class OpcionesModel extends FlutterFlowModel<OpcionesWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
