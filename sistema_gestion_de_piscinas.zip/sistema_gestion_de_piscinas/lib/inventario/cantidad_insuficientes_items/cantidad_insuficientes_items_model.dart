import '/flutter_flow/flutter_flow_util.dart';
import 'cantidad_insuficientes_items_widget.dart'
    show CantidadInsuficientesItemsWidget;
import 'package:flutter/material.dart';

class CantidadInsuficientesItemsModel
    extends FlutterFlowModel<CantidadInsuficientesItemsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
