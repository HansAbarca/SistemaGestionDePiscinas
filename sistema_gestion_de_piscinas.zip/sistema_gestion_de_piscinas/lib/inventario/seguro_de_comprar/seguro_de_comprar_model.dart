import '/flutter_flow/flutter_flow_util.dart';
import 'seguro_de_comprar_widget.dart' show SeguroDeComprarWidget;
import 'package:flutter/material.dart';

class SeguroDeComprarModel extends FlutterFlowModel<SeguroDeComprarWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
