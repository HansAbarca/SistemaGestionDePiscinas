import '/flutter_flow/flutter_flow_util.dart';
import 'guardar_cambios_widget.dart' show GuardarCambiosWidget;
import 'package:flutter/material.dart';

class GuardarCambiosModel extends FlutterFlowModel<GuardarCambiosWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
