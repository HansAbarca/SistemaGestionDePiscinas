import '/flutter_flow/flutter_flow_util.dart';
import 'carrito_item_widget.dart' show CarritoItemWidget;
import 'package:flutter/material.dart';

class CarritoItemModel extends FlutterFlowModel<CarritoItemWidget> {
  ///  Local state fields for this component.

  FFUploadedFile? imagenBytes;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
